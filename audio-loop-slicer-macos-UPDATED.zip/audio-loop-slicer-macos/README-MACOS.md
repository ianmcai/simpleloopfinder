# 🎵 Audio Loop Slicer - Mac OS Local Edition

A sophisticated web application for extracting perfect audio loops from your recordings with zero-crossing detection and rhythm analysis.

## ✨ Features

- **Smart Loop Detection**: Automatically finds up to 3 perfect loop candidates (≤3 seconds each)
- **Zero-Crossing Analysis**: Ensures seamless loops with no audio pops or clicks
- **Interactive Waveform**: Visual waveform display with region selection
- **Manual Adjustment**: Fine-tune loop boundaries with precision controls
- **Working Preview**: Listen to detected loops before exporting
- **Multiple Export Options**: Download individual loops or batch export all

## 📋 Mac OS Requirements

- **Node.js**: Version 18.0.0 or higher ([Download here](https://nodejs.org/))
- **npm**: Included with Node.js
- **Modern Browser**: Chrome, Firefox, Safari, or Edge

## 🚀 Quick Start (3 Easy Ways)

### Option 1: Double-Click Launcher (Easiest)
1. **Install Node.js** from [nodejs.org](https://nodejs.org/) if you haven't already
2. **Double-click** `Launch Audio Loop Slicer.command` file
3. The app will automatically install dependencies and start
4. Your browser will open at: `http://localhost:5173`

### Option 2: Setup Script
```bash
# Make the setup script executable
chmod +x setup-macos.sh

# Run the setup script
./setup-macos.sh

# Start the application
./launch.sh
```

### Option 3: Manual Setup
```bash
# Navigate to the application directory
cd audio-loop-slicer-macos

# Install dependencies
npm install

# Start the development server
npm run start
```

### Using Makefile (For Developers)
```bash
# Install dependencies
make setup

# Start development server
make dev

# See all available commands
make help
```

## 🎨 Alternative Package Managers (Optional)

The application is configured to work with standard **npm** (recommended). You can optionally use other package managers:

### Using yarn (alternative)
```bash
# Install yarn globally
npm install -g yarn

# Install dependencies
yarn install

# Start development server
yarn start
```

### Using pnpm (advanced users)
```bash
# Install pnpm globally
npm install -g pnpm

# Install dependencies
pnpm install

# Start development server
pnpm start
```

## 📖 Usage Instructions

1. **Upload Audio**: Click "Upload Audio File" and select your audio file (MP3, WAV, M4A, etc.)
2. **Wait for Analysis**: The app will analyze your audio and detect perfect loop candidates
3. **Review Candidates**: Detected loops appear in the "Loop Candidates" section with confidence scores
4. **Interactive Waveform**: Use the visual waveform to see loop regions and manually adjust boundaries
5. **Preview Loops**: Click "Preview" buttons to hear each loop before exporting
6. **Export**: Download individual loops or use "Export All Loops" for batch download

## 🔧 Advanced Features

### Manual Slice Adjustment
- Click "Manual Adjust" to enable region creation mode
- Click on the waveform to create custom regions
- Use the adjustment controls to fine-tune start and end times
- Preview your custom slices before export

### Audio Format Support
- **Input**: MP3, WAV, M4A, OGG, FLAC, and more
- **Output**: High-quality WAV files with original sample rate

## 🏗️ Build for Production

To create a production build:
```bash
npm run build
```

The built files will be in the `dist/` folder, ready for deployment to any web server.

## 🛠️ Troubleshooting

### Audio Not Playing
- Ensure your browser allows audio playback
- Check browser console for errors (F12 → Console)
- Try refreshing the page
- Make sure your audio file isn't corrupted

### Installation Issues
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules
npm install
```

### Performance Issues
- Use shorter audio files (under 30 seconds work best)
- Close other browser tabs if memory usage is high
- Ensure your Mac has sufficient RAM available

### Permission Issues
```bash
# Make scripts executable
chmod +x setup-macos.sh
chmod +x "Launch Audio Loop Slicer.command"
chmod +x launch.sh
```

## 🔍 Technical Details

- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite 6
- **Audio Processing**: Web Audio API + WaveSurfer.js
- **UI Framework**: TailwindCSS + Lucide React icons
- **Audio Analysis**: Custom zero-crossing detection algorithm

## 📁 Package Contents

```
audio-loop-slicer-macos/
├── README-MACOS.md              # This file
├── Launch Audio Loop Slicer.command  # Double-click launcher
├── setup-macos.sh               # Setup script
├── launch.sh                    # Launch script
├── Makefile                     # Make commands
├── package.json                 # Dependencies
├── vite.config.ts               # Vite configuration
├── src/                         # Source code
│   ├── components/              # React components
│   ├── lib/                     # Audio processing
│   └── ...
└── public/                      # Sample audio files
```

## 💡 Tips for Mac Users

1. **Use Terminal**: Open Terminal.app for running command-line instructions
2. **Homebrew**: Consider installing Homebrew for easier Node.js management
3. **Activity Monitor**: Monitor CPU/RAM usage if performance issues occur
4. **Safari**: Works great with Safari, Chrome, or Firefox

## 🆘 Support

For issues or questions:
1. Check the browser console for error messages (F12 → Console)
2. Ensure all dependencies are properly installed
3. Try with different audio file formats
4. Restart the development server
5. Check that Node.js version is 18.0.0 or higher

---

**Author**: MiniMax Agent  
**Version**: 1.0.0  
**Compatible**: Mac OS 10.15+ (Catalina and newer)  
**Last Updated**: January 2025
