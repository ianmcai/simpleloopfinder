import { saveAs } from 'file-saver';
import JSZip from 'jszip';
import { AudioAnalyzer } from './audioAnalysis';
import { LoopCandidate } from './audioAnalysis';

export class AudioExporter {
  private audioAnalyzer: AudioAnalyzer;

  constructor() {
    this.audioAnalyzer = new AudioAnalyzer();
  }

  async downloadSlice(
    audioBuffer: AudioBuffer,
    candidate: LoopCandidate,
    index: number,
    originalFileName: string = 'audio',
    crossfadeDuration?: number
  ): Promise<void> {
    try {
      const sliceBuffer = await this.audioAnalyzer.createAudioSlice(
        audioBuffer,
        candidate.startTime,
        candidate.endTime,
        crossfadeDuration || 0
      );
      
      const blob = await this.audioAnalyzer.exportAudioBuffer(sliceBuffer, 'wav');
      const fileName = this.generateFileName(originalFileName, index, candidate, crossfadeDuration);
      
      saveAs(blob, fileName);
    } catch (error) {
      console.error('Error downloading slice:', error);
      throw new Error('Failed to download audio slice');
    }
  }

  async downloadAllSlices(
    audioBuffer: AudioBuffer,
    candidates: LoopCandidate[],
    originalFileName: string = 'audio'
  ): Promise<void> {
    try {
      const zip = new JSZip();
      const folder = zip.folder('audio-loops');
      
      if (!folder) {
        throw new Error('Failed to create ZIP folder');
      }

      // Add each slice to the ZIP
      for (let i = 0; i < candidates.length; i++) {
        const candidate = candidates[i];
        const sliceBuffer = await this.audioAnalyzer.createAudioSlice(
          audioBuffer,
          candidate.startTime,
          candidate.endTime
        );
        
        const blob = await this.audioAnalyzer.exportAudioBuffer(sliceBuffer, 'wav');
        const fileName = this.generateFileName(originalFileName, i, candidate);
        
        folder.file(fileName, blob);
      }

      // Add metadata file
      const metadata = this.generateMetadata(candidates, originalFileName);
      folder.file('loop-info.json', JSON.stringify(metadata, null, 2));
      
      // Generate and download ZIP
      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const zipFileName = `${this.cleanFileName(originalFileName)}-loops.zip`;
      
      saveAs(zipBlob, zipFileName);
    } catch (error) {
      console.error('Error downloading all slices:', error);
      throw new Error('Failed to download audio slices');
    }
  }

  private generateFileName(
    originalFileName: string,
    index: number,
    candidate: LoopCandidate,
    crossfadeDuration?: number
  ): string {
    const baseName = this.cleanFileName(originalFileName);
    const duration = candidate.duration.toFixed(1);
    const confidence = Math.round(candidate.confidence * 100);
    
    let fileName = `${baseName}-loop-${index + 1}-${duration}s-${confidence}pct`;
    
    if (crossfadeDuration && crossfadeDuration > 0) {
      fileName += `-xfade${(crossfadeDuration * 1000).toFixed(0)}ms`;
    }
    
    return `${fileName}.wav`;
  }

  private cleanFileName(fileName: string): string {
    // Remove file extension and clean up the name
    const baseName = fileName.replace(/\.[^/.]+$/, '');
    return baseName.replace(/[^a-zA-Z0-9-_]/g, '_');
  }

  private generateMetadata(
    candidates: LoopCandidate[],
    originalFileName: string
  ): object {
    return {
      originalFile: originalFileName,
      exportDate: new Date().toISOString(),
      totalLoops: candidates.length,
      loops: candidates.map((candidate, index) => ({
        id: index + 1,
        startTime: candidate.startTime,
        endTime: candidate.endTime,
        duration: candidate.duration,
        confidence: candidate.confidence,
        zeroCrossingStart: candidate.zeroCrossingStart,
        zeroCrossingEnd: candidate.zeroCrossingEnd,
        rhythmScore: candidate.rhythmScore,
        fileName: this.generateFileName(originalFileName, index, candidate)
      }))
    };
  }

  async exportOriginalAudio(
    audioBuffer: AudioBuffer,
    originalFileName: string = 'audio'
  ): Promise<void> {
    try {
      const blob = await this.audioAnalyzer.exportAudioBuffer(audioBuffer, 'wav');
      const fileName = `${this.cleanFileName(originalFileName)}-original.wav`;
      
      saveAs(blob, fileName);
    } catch (error) {
      console.error('Error exporting original audio:', error);
      throw new Error('Failed to export original audio');
    }
  }
}