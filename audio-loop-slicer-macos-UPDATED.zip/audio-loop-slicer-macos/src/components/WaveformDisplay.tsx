import React, { useEffect, useRef, useState, useCallback } from 'react';
import WaveSurfer from 'wavesurfer.js';
import { Play, Pause, RotateCcw, Edit3, X } from 'lucide-react';
import { LoopCandidate } from '../lib/audioAnalysis';

interface Region {
  id: string;
  start: number;
  end: number;
  color: string;
  editable: boolean;
}

interface WaveformDisplayProps {
  audioBuffer: AudioBuffer | null;
  loopCandidates: LoopCandidate[];
  onRegionSelect?: (startTime: number, endTime: number) => void;
  onSliceUpdate?: (index: number, startTime: number, endTime: number) => void;
}

export const WaveformDisplay: React.FC<WaveformDisplayProps> = ({
  audioBuffer,
  loopCandidates,
  onRegionSelect,
  onSliceUpdate
}) => {
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurfer = useRef<WaveSurfer | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [regions, setRegions] = useState<Region[]>([]);
  const [isCreatingRegion, setIsCreatingRegion] = useState(false);
  const [audioReady, setAudioReady] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  
  // Web Audio API refs for preview functionality
  const audioContextRef = useRef<AudioContext | null>(null);
  const previewSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  useEffect(() => {
    if (!waveformRef.current) return;

    // Initialize WaveSurfer
    wavesurfer.current = WaveSurfer.create({
      container: waveformRef.current,
      waveColor: '#3b82f6',
      progressColor: '#1d4ed8',
      cursorColor: '#ef4444',
      barWidth: 2,
      barRadius: 1,
      height: 100,
      normalize: true,
      interact: true,
      backend: 'WebAudio'
    });

    // Event listeners
    wavesurfer.current.on('play', () => setIsPlaying(true));
    wavesurfer.current.on('pause', () => setIsPlaying(false));
    wavesurfer.current.on('audioprocess', (time) => setCurrentTime(time));
    wavesurfer.current.on('ready', () => {
      setDuration(wavesurfer.current?.getDuration() || 0);
      setAudioReady(true);
      setAudioError(null);
    });

    // Handle clicks for region creation
    wavesurfer.current.on('click', (progress) => {
      if (isCreatingRegion && duration > 0) {
        const time = progress * duration;
        createNewRegion(time);
      }
    });

    wavesurfer.current.on('error', (error) => {
      console.error('WaveSurfer error:', error);
      setAudioError('Failed to load audio for playback');
      setAudioReady(false);
    });

    return () => {
      if (wavesurfer.current) {
        wavesurfer.current.destroy();
      }
      if (previewSourceRef.current) {
        try {
          previewSourceRef.current.stop();
        } catch (e) {
          // Ignore errors if already stopped
        }
        previewSourceRef.current.disconnect();
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, [isCreatingRegion, duration]);

  useEffect(() => {
    if (audioBuffer && wavesurfer.current) {
      try {
        setAudioReady(false);
        setAudioError(null);
        
        // Clean up previous preview source when loading new audio
        if (previewSourceRef.current) {
          try {
            previewSourceRef.current.stop();
          } catch (e) {
            // Ignore errors if already stopped
          }
          previewSourceRef.current.disconnect();
          previewSourceRef.current = null;
        }
        
        // Reset preview state
        setIsPreviewing(false);
        
        console.log('Loading new audio buffer:', {
          channels: audioBuffer.numberOfChannels,
          length: audioBuffer.length,
          sampleRate: audioBuffer.sampleRate,
          duration: audioBuffer.duration
        });
        
        // Convert AudioBuffer to WAV blob for WaveSurfer
        const wavBlob = audioBufferToWavBlob(audioBuffer);
        const audioUrl = URL.createObjectURL(wavBlob);
        
        wavesurfer.current.load(audioUrl);
        
        // Clean up URL after loading
        setTimeout(() => {
          URL.revokeObjectURL(audioUrl);
        }, 5000);
        
      } catch (error) {
        console.error('Error loading audio:', error);
        setAudioError('Failed to prepare audio for playback');
      }
    }
  }, [audioBuffer]);

  // Initialize Web Audio API for preview functionality
  const initializeAudioContext = () => {
    // If context exists and is not closed, reuse it
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      console.log('Reusing existing audio context, state:', audioContextRef.current.state);
      return;
    }
    
    try {
      console.log('Creating new audio context...');
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      gainNodeRef.current = audioContextRef.current.createGain();
      gainNodeRef.current.connect(audioContextRef.current.destination);
      gainNodeRef.current.gain.value = 0.7;
      
      console.log('Audio context created successfully:', {
        state: audioContextRef.current.state,
        sampleRate: audioContextRef.current.sampleRate,
        destination: !!audioContextRef.current.destination
      });
    } catch (error) {
      console.error('Failed to initialize audio context:', error);
      setAudioError('Audio not supported in this browser');
    }
  };

  // Preview function for playing specific regions
  const previewFromTime = async (startTime: number, duration: number = 3) => {
    console.log('Preview requested:', { startTime, duration, audioBufferExists: !!audioBuffer });
    
    if (!audioBuffer) {
      console.error('Audio buffer not available for preview');
      setAudioError('Audio buffer not available for preview');
      return;
    }

    console.log('Audio buffer details:', {
      channels: audioBuffer.numberOfChannels,
      length: audioBuffer.length,
      sampleRate: audioBuffer.sampleRate,
      duration: audioBuffer.duration
    });

    initializeAudioContext();
    
    if (!audioContextRef.current || !gainNodeRef.current) {
      console.error('Failed to initialize audio context for preview');
      setAudioError('Failed to initialize audio context');
      return;
    }

    console.log('Audio context state:', audioContextRef.current.state);

    try {
      // Stop any current preview
      if (previewSourceRef.current) {
        try {
          previewSourceRef.current.stop();
        } catch (e) {
          // Ignore errors if already stopped
        }
        previewSourceRef.current.disconnect();
        previewSourceRef.current = null;
      }

      // Resume audio context if suspended
      if (audioContextRef.current.state === 'suspended') {
        console.log('Resuming suspended audio context...');
        await audioContextRef.current.resume();
        console.log('Audio context resumed, new state:', audioContextRef.current.state);
      }

      // Create audio source for preview
      previewSourceRef.current = audioContextRef.current.createBufferSource();
      previewSourceRef.current.buffer = audioBuffer;
      previewSourceRef.current.connect(gainNodeRef.current);
      
      console.log(`Starting preview playback from ${startTime.toFixed(2)}s for ${duration}s`);
      
      // Handle preview end
      previewSourceRef.current.onended = () => {
        console.log('Preview ended naturally');
        previewSourceRef.current = null;
        setIsPreviewing(false);
      };
      
      // AudioBufferSourceNode doesn't have onerror event
      // Error handling is done in the try-catch block
      
      // Start playback from the specified time
      const endTime = Math.min(startTime + duration, audioBuffer.duration);
      const playDuration = endTime - startTime;
      
      console.log('Playback details:', { startTime, endTime, playDuration });
      
      previewSourceRef.current.start(0, startTime, playDuration);
      setIsPreviewing(true);
      setAudioError(null);
      
      console.log('Preview started successfully');
      
      // Auto-stop after preview duration
      setTimeout(() => {
        if (previewSourceRef.current) {
          try {
            console.log('Auto-stopping preview');
            previewSourceRef.current.stop();
          } catch (e) {
            // Already stopped
          }
        }
        setIsPreviewing(false);
      }, playDuration * 1000 + 100); // Add 100ms buffer
      
    } catch (error) {
      console.error('Failed to play preview:', error);
      setAudioError('Failed to play preview: ' + error.message);
      setIsPreviewing(false);
    }
  };

  // Helper function to convert AudioBuffer to WAV Blob
  const audioBufferToWavBlob = (buffer: AudioBuffer): Blob => {
    const length = buffer.length;
    const numberOfChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const bytesPerSample = 2;
    const blockAlign = numberOfChannels * bytesPerSample;
    const byteRate = sampleRate * blockAlign;
    const dataLength = length * blockAlign;
    const bufferLength = 44 + dataLength;
    
    const arrayBuffer = new ArrayBuffer(bufferLength);
    const view = new DataView(arrayBuffer);
    
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    // RIFF chunk descriptor
    writeString(0, 'RIFF');
    view.setUint32(4, bufferLength - 8, true);
    writeString(8, 'WAVE');
    
    // fmt sub-chunk
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, 16, true);
    
    // data sub-chunk
    writeString(36, 'data');
    view.setUint32(40, dataLength, true);
    
    // Write audio data
    let offset = 44;
    for (let i = 0; i < length; i++) {
      for (let channel = 0; channel < numberOfChannels; channel++) {
        const sample = buffer.getChannelData(channel)[i];
        const intSample = Math.max(-1, Math.min(1, sample)) * 0x7FFF;
        view.setInt16(offset, intSample, true);
        offset += 2;
      }
    }
    
    return new Blob([arrayBuffer], { type: 'audio/wav' });
  };

  useEffect(() => {
    // Update regions when loop candidates change
    if (loopCandidates.length > 0) {
      const colors = ['#22c55e', '#eab308', '#f97316'];
      const newRegions = loopCandidates.map((candidate, index) => ({
        id: `loop-${index}`,
        start: candidate.startTime,
        end: candidate.endTime,
        color: colors[index % colors.length],
        editable: false
      }));
      setRegions(newRegions);
    }
  }, [loopCandidates]);

  const createNewRegion = useCallback((startTime: number) => {
    const endTime = Math.min(startTime + 2, duration);
    const newRegion: Region = {
      id: `custom-${Date.now()}`,
      start: startTime,
      end: endTime,
      color: '#8b5cf6',
      editable: true
    };
    setRegions(prev => [...prev, newRegion]);
    setIsCreatingRegion(false);
    if (onRegionSelect) {
      onRegionSelect(startTime, endTime);
    }
  }, [duration, onRegionSelect]);

  const updateRegion = useCallback((regionId: string, start: number, end: number) => {
    setRegions(prev => prev.map(region => 
      region.id === regionId ? { ...region, start, end } : region
    ));
    
    const regionIndex = regions.findIndex(r => r.id === regionId);
    if (regionIndex >= 0 && regionIndex < loopCandidates.length && onSliceUpdate) {
      onSliceUpdate(regionIndex, start, end);
    }
  }, [regions, loopCandidates, onSliceUpdate]);

  const deleteRegion = useCallback((regionId: string) => {
    setRegions(prev => prev.filter(region => region.id !== regionId));
  }, []);

  const handlePlayPause = async () => {
    if (wavesurfer.current) {
      // Stop any preview first
      if (previewSourceRef.current) {
        try {
          previewSourceRef.current.stop();
        } catch (e) {
          // Ignore errors
        }
        setIsPreviewing(false);
      }
      
      wavesurfer.current.playPause();
    }
  };

  const handleStop = () => {
    if (wavesurfer.current) {
      wavesurfer.current.stop();
      setIsPlaying(false);
      setCurrentTime(0);
    }
    if (previewSourceRef.current) {
      try {
        previewSourceRef.current.stop();
      } catch (e) {
        // Ignore errors
      }
      setIsPreviewing(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Test audio function to verify Web Audio API is working
  const testAudio = async () => {
    initializeAudioContext();
    
    if (!audioContextRef.current || !gainNodeRef.current) {
      console.error('Audio context not available for test');
      setAudioError('Audio context not available');
      return;
    }

    try {
      // Resume audio context if suspended
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      // Create a simple beep for testing
      const oscillator = audioContextRef.current.createOscillator();
      const testGain = audioContextRef.current.createGain();
      
      oscillator.connect(testGain);
      testGain.connect(audioContextRef.current.destination);
      
      oscillator.frequency.setValueAtTime(440, audioContextRef.current.currentTime); // A4 note
      testGain.gain.setValueAtTime(0.1, audioContextRef.current.currentTime);
      testGain.gain.exponentialRampToValueAtTime(0.01, audioContextRef.current.currentTime + 0.5);
      
      oscillator.start(audioContextRef.current.currentTime);
      oscillator.stop(audioContextRef.current.currentTime + 0.5);
      
      console.log('Test beep played successfully');
      setAudioError(null);
    } catch (error) {
      console.error('Test audio failed:', error);
      setAudioError('Test audio failed: ' + error.message);
    }
  };

  return (
    <div className="w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            Interactive Waveform
          </h3>
          <button
            onClick={() => setIsCreatingRegion(!isCreatingRegion)}
            disabled={!audioBuffer}
            className={`flex items-center gap-2 px-3 py-1 text-sm rounded-lg transition-colors ${
              isCreatingRegion 
                ? 'bg-purple-600 text-white hover:bg-purple-700' 
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            } disabled:opacity-50`}
          >
            <Edit3 className="h-4 w-4" />
            {isCreatingRegion ? 'Click to Add Region' : 'Manual Adjust'}
          </button>
        </div>
        
        {/* Controls */}
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={handlePlayPause}
            disabled={!audioBuffer || !audioReady}
            className="flex items-center justify-center w-10 h-10 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-full transition-colors"
            title={!audioReady ? 'Audio loading...' : 'Play/Pause audio'}
          >
            {isPlaying ? (
              <Pause className="h-5 w-5" />
            ) : (
              <Play className="h-5 w-5 ml-0.5" />
            )}
          </button>
          
          <button
            onClick={handleStop}
            disabled={!audioBuffer}
            className="flex items-center justify-center w-10 h-10 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white rounded-full transition-colors"
          >
            <RotateCcw className="h-5 w-5" />
          </button>
          
          <button
            onClick={testAudio}
            className="px-3 py-1 text-xs bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
            title="Test Web Audio API with a beep sound"
          >
            Test Audio
          </button>
          
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
          
          {audioError && (
            <div className="text-sm text-red-500">
              {audioError}
            </div>
          )}
          
          {!audioReady && audioBuffer && !audioError && (
            <div className="text-sm text-yellow-600">
              Loading audio...
            </div>
          )}
          
          {audioReady && !isPreviewing && !isPlaying && (
            <div className="text-sm text-green-600">
              ♪ Audio ready
            </div>
          )}
          
          {isPreviewing && (
            <div className="text-sm text-blue-600 font-medium">
              🎵 Playing preview...
            </div>
          )}
          
          <div className="flex-1" />
          
          {isCreatingRegion && (
            <div className="text-sm text-purple-600 dark:text-purple-400 font-medium">
              Click on waveform to create new region
            </div>
          )}
        </div>
      </div>
      
      {/* Waveform */}
      <div className="relative">
        <div ref={waveformRef} className="w-full border rounded-lg" />
        
        {/* Interactive regions overlay */}
        {regions.length > 0 && duration > 0 && (
          <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
            {regions.map((region) => {
              const leftPercent = (region.start / duration) * 100;
              const widthPercent = ((region.end - region.start) / duration) * 100;
              
              return (
                <div
                  key={region.id}
                  className="absolute top-0 h-full border-2 rounded"
                  style={{
                    left: `${leftPercent}%`,
                    width: `${widthPercent}%`,
                    backgroundColor: region.color + '30',
                    borderColor: region.color
                  }}
                  title={`${region.start.toFixed(2)}s - ${region.end.toFixed(2)}s`}
                />
              );
            })}
          </div>
        )}
      </div>
      
      {/* Manual adjustment controls */}
      {regions.length > 0 && (
        <div className="mt-6">
          <h4 className="text-md font-semibold text-gray-900 dark:text-gray-100 mb-3">
            Manual Slice Adjustment
          </h4>
          <div className="space-y-3">
            {regions.map((region, index) => (
              <div key={region.id} className="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div 
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: region.color }}
                />
                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      Start Time (s)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max={duration}
                      value={region.start.toFixed(2)}
                      onChange={(e) => {
                        const newStart = Math.max(0, Math.min(parseFloat(e.target.value) || 0, region.end - 0.1));
                        updateRegion(region.id, newStart, region.end);
                      }}
                      className="w-full px-2 py-1 text-sm border rounded dark:bg-gray-600 dark:border-gray-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      End Time (s)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max={duration}
                      value={region.end.toFixed(2)}
                      onChange={(e) => {
                        const newEnd = Math.min(duration, Math.max(parseFloat(e.target.value) || 0, region.start + 0.1));
                        updateRegion(region.id, region.start, newEnd);
                      }}
                      className="w-full px-2 py-1 text-sm border rounded dark:bg-gray-600 dark:border-gray-500"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Duration: {(region.end - region.start).toFixed(2)}s
                    </span>
                    <button
                      onClick={() => previewFromTime(region.start, Math.min(region.end - region.start, 3))}
                      className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
                      title={`Preview ${(region.end - region.start).toFixed(1)}s from ${region.start.toFixed(1)}s`}
                    >
                      Preview
                    </button>
                    {region.editable && (
                      <button
                        onClick={() => deleteRegion(region.id)}
                        className="px-2 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Legend */}
      {loopCandidates.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-4 text-sm">
          {loopCandidates.map((candidate, index) => {
            const colors = ['text-green-600', 'text-yellow-600', 'text-orange-600'];
            const bgColors = ['bg-green-100', 'bg-yellow-100', 'bg-orange-100'];
            
            return (
              <div key={index} className={`flex items-center gap-2 px-3 py-1 rounded-full ${bgColors[index]}`}>
                <div className={`w-3 h-3 rounded-full ${colors[index].replace('text-', 'bg-')}`} />
                <span className={`font-medium ${colors[index]}`}>
                  Loop {index + 1} ({candidate.duration.toFixed(1)}s)
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
