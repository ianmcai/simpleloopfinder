import React from 'react';
import { Download, Package, Music } from 'lucide-react';
import { LoopCandidate } from '../lib/audioAnalysis';

interface ExportControlsProps {
  candidates: LoopCandidate[];
  onDownloadAll: () => void;
  onExportOriginal: () => void;
  isExporting: boolean;
}

export const ExportControls: React.FC<ExportControlsProps> = ({
  candidates,
  onDownloadAll,
  onExportOriginal,
  isExporting
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
        Export Options
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={onDownloadAll}
          disabled={candidates.length === 0 || isExporting}
          className="flex items-center justify-center gap-3 p-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-lg transition-colors"
        >
          {isExporting ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <Package className="h-5 w-5" />
          )}
          <div className="text-left">
            <div className="font-medium">
              {isExporting ? 'Preparing...' : 'Download All Loops'}
            </div>
            <div className="text-sm opacity-90">
              ZIP file with {candidates.length} loops
            </div>
          </div>
        </button>
        
        <button
          onClick={onExportOriginal}
          disabled={candidates.length === 0 || isExporting}
          className="flex items-center justify-center gap-3 p-4 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white rounded-lg transition-colors"
        >
          <Music className="h-5 w-5" />
          <div className="text-left">
            <div className="font-medium">Export Original</div>
            <div className="text-sm opacity-90">WAV format</div>
          </div>
        </button>
      </div>
      
      {candidates.length > 0 && (
        <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <Download className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="text-sm text-blue-800 dark:text-blue-200">
              <p className="font-medium mb-1">Export Information:</p>
              <ul className="space-y-1 text-blue-700 dark:text-blue-300">
                <li>• All slices exported as uncompressed WAV files</li>
                <li>• Includes metadata file with loop details</li>
                <li>• Individual downloads available on each loop card</li>
                <li>• Zero-crossing cuts ensure clean loops</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};