import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Download, Volume2, RotateCcw, Zap } from 'lucide-react';
import { LoopCandidate, AudioAnalyzer } from '../lib/audioAnalysis';

interface LoopSliceCardProps {
  candidate: LoopCandidate;
  audioBuffer: AudioBuffer;
  index: number;
  onDownload: (candidate: LoopCandidate, index: number, crossfadeDuration?: number) => void;
}

export const LoopSliceCard: React.FC<LoopSliceCardProps> = ({
  candidate,
  audioBuffer,
  index,
  onDownload
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [crossfadeEnabled, setCrossfadeEnabled] = useState(false);
  const [crossfadeDuration, setCrossfadeDuration] = useState(0.1);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const sliceBufferRef = useRef<AudioBuffer | null>(null);
  const crossfadeBufferRef = useRef<AudioBuffer | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const analyzerRef = useRef<AudioAnalyzer | null>(null);
  const [volume, setVolume] = useState(0.7);

  const colors = [
    { bg: 'bg-green-50 dark:bg-green-950/20', border: 'border-green-200 dark:border-green-800', accent: 'text-green-600 dark:text-green-400' },
    { bg: 'bg-yellow-50 dark:bg-yellow-950/20', border: 'border-yellow-200 dark:border-yellow-800', accent: 'text-yellow-600 dark:text-yellow-400' },
    { bg: 'bg-orange-50 dark:bg-orange-950/20', border: 'border-orange-200 dark:border-orange-800', accent: 'text-orange-600 dark:text-orange-400' }
  ];

  const colorScheme = colors[index % colors.length];

  useEffect(() => {
    // Initialize audio context
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Initialize audio analyzer
    analyzerRef.current = new AudioAnalyzer();
    
    // Create gain node for volume control
    gainNodeRef.current = audioContextRef.current.createGain();
    gainNodeRef.current.connect(audioContextRef.current.destination);
    gainNodeRef.current.gain.value = volume;

    return () => {
      if (sourceRef.current) {
        sourceRef.current.disconnect();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = volume;
    }
  }, [volume]);

  useEffect(() => {
    // Create audio slice when component mounts or candidate changes
    createAudioSlice();
  }, [candidate, audioBuffer, crossfadeEnabled, crossfadeDuration]);

  const createAudioSlice = async () => {
    if (!audioContextRef.current || !analyzerRef.current) return;

    // Create basic slice
    const startSample = Math.floor(candidate.startTime * audioBuffer.sampleRate);
    const endSample = Math.floor(candidate.endTime * audioBuffer.sampleRate);
    const length = endSample - startSample;
    
    const sliceBuffer = audioContextRef.current.createBuffer(
      audioBuffer.numberOfChannels,
      length,
      audioBuffer.sampleRate
    );
    
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const originalData = audioBuffer.getChannelData(channel);
      const sliceData = sliceBuffer.getChannelData(channel);
      
      for (let i = 0; i < length; i++) {
        sliceData[i] = originalData[startSample + i];
      }
    }
    
    sliceBufferRef.current = sliceBuffer;

    // Create crossfade version if enabled
    if (crossfadeEnabled && crossfadeDuration > 0) {
      try {
        const crossfadeBuffer = analyzerRef.current.applyCrossfade(sliceBuffer, crossfadeDuration);
        crossfadeBufferRef.current = crossfadeBuffer;
      } catch (error) {
        console.warn('Crossfade creation failed:', error);
        crossfadeBufferRef.current = sliceBuffer;
      }
    } else {
      crossfadeBufferRef.current = sliceBuffer;
    }
  };

  const playSlice = (loop: boolean = false) => {
    if (!audioContextRef.current || !gainNodeRef.current) return;

    // Choose the appropriate buffer
    const bufferToPlay = crossfadeEnabled && crossfadeBufferRef.current 
      ? crossfadeBufferRef.current 
      : sliceBufferRef.current;

    if (!bufferToPlay) return;

    // Stop current playback
    stopSlice();

    const source = audioContextRef.current.createBufferSource();
    source.buffer = bufferToPlay;
    source.loop = loop;
    source.connect(gainNodeRef.current);
    
    sourceRef.current = source;
    setIsPlaying(true);
    setIsLooping(loop);
    
    source.onended = () => {
      if (!loop) {
        setIsPlaying(false);
        setIsLooping(false);
      }
    };
    
    source.start();
  };

  const stopSlice = () => {
    if (sourceRef.current) {
      sourceRef.current.stop();
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    setIsPlaying(false);
    setIsLooping(false);
  };

  const handlePlayPause = () => {
    if (isPlaying) {
      stopSlice();
    } else {
      playSlice(false);
    }
  };

  const handleLoopToggle = () => {
    if (isLooping) {
      stopSlice();
    } else {
      playSlice(true);
    }
  };

  const formatTime = (seconds: number) => {
    return `${seconds.toFixed(2)}s`;
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600 dark:text-green-400';
    if (confidence >= 0.6) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-orange-600 dark:text-orange-400';
  };

  return (
    <div className={`${colorScheme.bg} ${colorScheme.border} border rounded-xl p-6 space-y-4`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className={`text-lg font-semibold ${colorScheme.accent}`}>
          Loop {index + 1}
        </h3>
        <div className="flex items-center gap-2">
          <span className={`text-sm font-medium ${getConfidenceColor(candidate.confidence)}`}>
            {Math.round(candidate.confidence * 100)}% confidence
          </span>
        </div>
      </div>

      {/* Loop Info */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <span className="text-gray-600 dark:text-gray-400">Duration:</span>
          <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">
            {formatTime(candidate.duration)}
          </span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">Range:</span>
          <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">
            {formatTime(candidate.startTime)} - {formatTime(candidate.endTime)}
          </span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">Clean cuts:</span>
          <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">
            {candidate.zeroCrossingStart && candidate.zeroCrossingEnd ? '✓ Both' : 
             candidate.zeroCrossingStart || candidate.zeroCrossingEnd ? '~ Partial' : '✗ None'}
          </span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">Rhythm:</span>
          <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">
            {Math.round(candidate.rhythmScore * 100)}%
          </span>
        </div>
      </div>

      {/* Volume Control */}
      <div className="flex items-center gap-3">
        <Volume2 className="h-4 w-4 text-gray-600 dark:text-gray-400" />
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={volume}
          onChange={(e) => setVolume(parseFloat(e.target.value))}
          className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
        />
        <span className="text-sm text-gray-600 dark:text-gray-400 w-8">
          {Math.round(volume * 100)}%
        </span>
      </div>

      {/* Crossfade Control */}
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCrossfadeEnabled(!crossfadeEnabled)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              crossfadeEnabled 
                ? 'bg-purple-600 text-white hover:bg-purple-700' 
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            <Zap className="h-4 w-4" />
            <span>Crossfade</span>
          </button>
          {crossfadeEnabled && (
            <span className="text-xs text-purple-600 dark:text-purple-400 font-medium">
              Smooth loop transitions enabled
            </span>
          )}
        </div>
        
        {crossfadeEnabled && (
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600 dark:text-gray-400 w-16">Duration:</span>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={crossfadeDuration}
              onChange={(e) => setCrossfadeDuration(parseFloat(e.target.value))}
              className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-sm text-gray-600 dark:text-gray-400 w-12">
              {(crossfadeDuration * 1000).toFixed(0)}ms
            </span>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          onClick={handlePlayPause}
          className={`flex items-center justify-center w-10 h-10 ${isPlaying ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'} text-white rounded-full transition-colors`}
        >
          {isPlaying ? (
            <Pause className="h-5 w-5" />
          ) : (
            <Play className="h-5 w-5 ml-0.5" />
          )}
        </button>
        
        <button
          onClick={handleLoopToggle}
          className={`flex items-center justify-center w-10 h-10 ${isLooping ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 hover:bg-gray-700'} text-white rounded-full transition-colors`}
          title="Loop playback"
        >
          <RotateCcw className="h-5 w-5" />
        </button>
        
        <div className="flex-1" />
        
        <button
          onClick={() => onDownload(candidate, index, crossfadeEnabled ? crossfadeDuration : undefined)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
        >
          <Download className="h-4 w-4" />
          <span className="font-medium">Download</span>
        </button>
      </div>
    </div>
  );
};