import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Music } from 'lucide-react';

interface AudioUploadProps {
  onFileUpload: (file: File) => void;
  isProcessing: boolean;
}

export const AudioUpload: React.FC<AudioUploadProps> = ({ onFileUpload, isProcessing }) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFileUpload(acceptedFiles[0]);
    }
  }, [onFileUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
    },
    multiple: false,
    disabled: isProcessing
  });

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-300
          ${isDragActive 
            ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' 
            : 'border-gray-300 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500'
          }
          ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center gap-4">
          {isProcessing ? (
            <div className="flex items-center gap-3">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
              <span className="text-lg font-medium text-gray-700 dark:text-gray-300">
                Processing audio...
              </span>
            </div>
          ) : (
            <>
              <div className="p-4 rounded-full bg-blue-100 dark:bg-blue-900/30">
                {isDragActive ? (
                  <Upload className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                ) : (
                  <Music className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                )}
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                  {isDragActive ? 'Drop your audio file here' : 'Upload Audio File'}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {isDragActive 
                    ? 'Release to upload' 
                    : 'Drag & drop an audio file or click to browse'
                  }
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-500">
                  Supports MP3, WAV, M4A, AAC, OGG, FLAC (max 50MB)
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};