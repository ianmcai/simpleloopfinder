import React, { useState, useCallback } from 'react';
import { AudioUpload } from './components/AudioUpload';
import { WaveformDisplay } from './components/WaveformDisplay';
import { LoopSliceCard } from './components/LoopSliceCard';
import { ExportControls } from './components/ExportControls';
import { AudioAnalyzer, AudioAnalysisResult, LoopCandidate } from './lib/audioAnalysis';
import { AudioExporter } from './lib/audioExport';
import { AudioWaveform, AlertCircle, CheckCircle, Sparkles } from 'lucide-react';

function App() {
  const [analysisResult, setAnalysisResult] = useState<AudioAnalysisResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [success, setSuccess] = useState<string | null>(null);

  const audioAnalyzer = new AudioAnalyzer();
  const audioExporter = new AudioExporter();

  const handleFileUpload = useCallback(async (file: File) => {
    setIsProcessing(true);
    setError(null);
    setSuccess(null);
    setUploadedFileName(file.name);
    
    try {
      const result = await audioAnalyzer.analyzeAudioFile(file);
      setAnalysisResult(result);
      
      if (result.loopCandidates.length === 0) {
        setError('No suitable loop candidates found. Try a file with more rhythmic content.');
      } else {
        setSuccess(`Found ${result.loopCandidates.length} potential loop${result.loopCandidates.length === 1 ? '' : 's'}!`);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setError('Failed to analyze audio file. Please ensure it\'s a valid audio format.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const handleSliceUpdate = useCallback((index: number, startTime: number, endTime: number) => {
    if (!analysisResult) return;
    
    const updatedCandidates = [...analysisResult.loopCandidates];
    if (updatedCandidates[index]) {
      updatedCandidates[index] = {
        ...updatedCandidates[index],
        startTime,
        endTime,
        duration: endTime - startTime
      };
      
      setAnalysisResult({
        ...analysisResult,
        loopCandidates: updatedCandidates
      });
      
      setSuccess('Slice boundaries updated successfully!');
    }
  }, [analysisResult]);

  const loadDemoAudio = useCallback(async (fileName: string) => {
    setIsProcessing(true);
    setError(null);
    setSuccess(null);
    
    try {
      const response = await fetch(`/${fileName}`);
      if (!response.ok) throw new Error('Failed to load demo file');
      
      const blob = await response.blob();
      const file = new File([blob], fileName, { type: 'audio/mpeg' });
      
      setUploadedFileName(fileName);
      const result = await audioAnalyzer.analyzeAudioFile(file);
      setAnalysisResult(result);
      
      if (result.loopCandidates.length === 0) {
        setError('No suitable loop candidates found in demo file.');
      } else {
        setSuccess(`Demo loaded! Found ${result.loopCandidates.length} potential loop${result.loopCandidates.length === 1 ? '' : 's'}!`);
      }
    } catch (err) {
      console.error('Demo load error:', err);
      setError('Failed to load demo audio file.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const handleDownloadSlice = useCallback(async (candidate: LoopCandidate, index: number, crossfadeDuration?: number) => {
    if (!analysisResult) return;
    
    try {
      await audioExporter.downloadSlice(
        analysisResult.audioBuffer,
        candidate,
        index,
        uploadedFileName,
        crossfadeDuration
      );
    } catch (err) {
      console.error('Download error:', err);
      setError('Failed to download audio slice.');
    }
  }, [analysisResult, uploadedFileName]);

  const handleDownloadAll = useCallback(async () => {
    if (!analysisResult) return;
    
    setIsExporting(true);
    try {
      await audioExporter.downloadAllSlices(
        analysisResult.audioBuffer,
        analysisResult.loopCandidates,
        uploadedFileName
      );
      setSuccess('All loops downloaded successfully!');
    } catch (err) {
      console.error('Export error:', err);
      setError('Failed to export audio loops.');
    } finally {
      setIsExporting(false);
    }
  }, [analysisResult, uploadedFileName]);

  const handleExportOriginal = useCallback(async () => {
    if (!analysisResult) return;
    
    try {
      await audioExporter.exportOriginalAudio(
        analysisResult.audioBuffer,
        uploadedFileName
      );
      setSuccess('Original audio exported successfully!');
    } catch (err) {
      console.error('Export error:', err);
      setError('Failed to export original audio.');
    }
  }, [analysisResult, uploadedFileName]);

  const clearMessages = () => {
    setError(null);
    setSuccess(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl">
              <AudioWaveform className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Audio Loop Slicer
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Intelligent audio analysis for perfect loops
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Messages */}
        {(error || success) && (
          <div className="mb-6">
            {error && (
              <div className="flex items-start gap-3 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-red-800 dark:text-red-200 font-medium">{error}</p>
                </div>
                <button
                  onClick={clearMessages}
                  className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-200"
                >
                  ×
                </button>
              </div>
            )}
            
            {success && (
              <div className="flex items-start gap-3 p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-green-800 dark:text-green-200 font-medium">{success}</p>
                </div>
                <button
                  onClick={clearMessages}
                  className="text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200"
                >
                  ×
                </button>
              </div>
            )}
          </div>
        )}

        {/* Upload Section */}
        <div className="mb-8">
          <AudioUpload onFileUpload={handleFileUpload} isProcessing={isProcessing} />
        </div>

        {/* Demo Section */}
        <div className="mb-8">
          <div className="max-w-2xl mx-auto">
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20 border border-purple-200 dark:border-purple-800 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                Try Demo Audio Samples
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Test the audio loop slicer with pre-loaded sample files to see the full functionality in action.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <button
                  onClick={() => loadDemoAudio('sunflower-street-drumloop-85bpm-163900.mp3')}
                  disabled={isProcessing}
                  className="flex flex-col items-center p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors disabled:opacity-50"
                >
                  <span className="font-medium text-gray-900 dark:text-gray-100">Drum Loop</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">85 BPM • 11s</span>
                </button>
                <button
                  onClick={() => loadDemoAudio('clean-trap-loop-131bpm-136738.mp3')}
                  disabled={isProcessing}
                  className="flex flex-col items-center p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors disabled:opacity-50"
                >
                  <span className="font-medium text-gray-900 dark:text-gray-100">Trap Loop</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">131 BPM • 7s</span>
                </button>
                <button
                  onClick={() => loadDemoAudio('marimba-loop-2-39973.mp3')}
                  disabled={isProcessing}
                  className="flex flex-col items-center p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors disabled:opacity-50"
                >
                  <span className="font-medium text-gray-900 dark:text-gray-100">Marimba Loop</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Melodic • 8s</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Results Section */}
        {analysisResult && (
          <div className="space-y-8">
            {/* Waveform Display */}
            <WaveformDisplay
              audioBuffer={analysisResult.audioBuffer}
              loopCandidates={analysisResult.loopCandidates}
              onSliceUpdate={handleSliceUpdate}
            />

            {/* Loop Candidates */}
            {analysisResult.loopCandidates.length > 0 && (
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                    <Sparkles className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                    Detected Loop Candidates
                  </h2>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
                  {analysisResult.loopCandidates.map((candidate, index) => (
                    <LoopSliceCard
                      key={index}
                      candidate={candidate}
                      audioBuffer={analysisResult.audioBuffer}
                      index={index}
                      onDownload={handleDownloadSlice}
                    />
                  ))}
                </div>

                {/* Export Controls */}
                <ExportControls
                  candidates={analysisResult.loopCandidates}
                  onDownloadAll={handleDownloadAll}
                  onExportOriginal={handleExportOriginal}
                  isExporting={isExporting}
                />
              </div>
            )}
          </div>
        )}

        {/* Info Section */}
        {!analysisResult && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">
                How It Works
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="p-4 bg-blue-100 dark:bg-blue-900/30 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">1</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    Upload Audio
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Drag and drop or click to upload your audio file in any common format
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="p-4 bg-purple-100 dark:bg-purple-900/30 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <span className="text-2xl font-bold text-purple-600 dark:text-purple-400">2</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    AI Analysis
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Advanced algorithms detect zero-crossings and identify perfect loop candidates
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="p-4 bg-green-100 dark:bg-green-900/30 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <span className="text-2xl font-bold text-green-600 dark:text-green-400">3</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    Download Loops
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Preview, test, and download your perfect loops ready for production
                  </p>
                </div>
              </div>
              
              <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                  Features
                </h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-gray-700 dark:text-gray-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    Zero-crossing detection for clean cuts
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    Rhythm pattern analysis
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    Real-time audio preview
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    Seamless loop testing
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    Batch export functionality
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    High-quality WAV output
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-t border-gray-200 dark:border-gray-700 mt-16">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-gray-600 dark:text-gray-400">
            <p>
              Built for music producers, content creators, and audio enthusiasts.
            </p>
            <p className="mt-1 text-sm">
              All processing happens locally in your browser for maximum privacy and speed.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;