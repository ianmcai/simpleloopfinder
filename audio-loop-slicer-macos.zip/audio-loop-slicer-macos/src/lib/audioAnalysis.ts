export interface LoopCandidate {
  startTime: number;
  endTime: number;
  duration: number;
  confidence: number;
  zeroCrossingStart: boolean;
  zeroCrossingEnd: boolean;
  rhythmScore: number;
  crossfadeDuration?: number; // Optional crossfade duration in seconds
}

export interface AudioAnalysisResult {
  audioBuffer: AudioBuffer;
  duration: number;
  sampleRate: number;
  loopCandidates: LoopCandidate[];
  zeroCrossings: number[];
}

export class AudioAnalyzer {
  private audioContext: AudioContext;

  constructor() {
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }

  async analyzeAudioFile(file: File): Promise<AudioAnalysisResult> {
    const arrayBuffer = await file.arrayBuffer();
    const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
    
    const channelData = audioBuffer.getChannelData(0); // Use first channel for analysis
    const zeroCrossings = this.detectZeroCrossings(channelData, audioBuffer.sampleRate);
    const loopCandidates = await this.findLoopCandidates(channelData, audioBuffer.sampleRate, audioBuffer.duration, zeroCrossings);
    
    return {
      audioBuffer,
      duration: audioBuffer.duration,
      sampleRate: audioBuffer.sampleRate,
      loopCandidates,
      zeroCrossings
    };
  }

  private detectZeroCrossings(channelData: Float32Array, sampleRate: number): number[] {
    const zeroCrossings: number[] = [];
    const threshold = 0.01; // Small threshold to account for noise
    
    for (let i = 1; i < channelData.length; i++) {
      const prev = channelData[i - 1];
      const curr = channelData[i];
      
      // Detect zero crossing (sign change)
      if ((prev <= -threshold && curr >= threshold) || (prev >= threshold && curr <= -threshold)) {
        const timePosition = i / sampleRate;
        zeroCrossings.push(timePosition);
      }
    }
    
    return zeroCrossings;
  }

  private async findLoopCandidates(
    channelData: Float32Array, 
    sampleRate: number, 
    duration: number,
    zeroCrossings: number[]
  ): Promise<LoopCandidate[]> {
    const candidates: LoopCandidate[] = [];
    const maxDuration = 3.0; // Maximum 3 seconds per slice
    const minDuration = 0.5; // Minimum 0.5 seconds per slice
    
    // Analyze different potential loop lengths
    const targetDurations = [1.0, 1.5, 2.0, 2.5, 3.0]; // Common loop durations
    
    for (const targetDuration of targetDurations) {
      if (targetDuration > duration) continue;
      
      // Try different starting positions
      const numPositions = Math.floor((duration - targetDuration) * 10); // Every 0.1 seconds
      
      for (let i = 0; i < numPositions; i++) {
        const startTime = i * 0.1;
        const endTime = startTime + targetDuration;
        
        if (endTime > duration) break;
        
        const candidate = await this.evaluateLoopCandidate(
          channelData,
          sampleRate,
          startTime,
          endTime,
          zeroCrossings
        );
        
        if (candidate.confidence > 0.3) { // Only keep decent candidates
          candidates.push(candidate);
        }
      }
    }
    
    // Sort by confidence and return top 3
    candidates.sort((a, b) => b.confidence - a.confidence);
    return candidates.slice(0, 3);
  }

  private async evaluateLoopCandidate(
    channelData: Float32Array,
    sampleRate: number,
    startTime: number,
    endTime: number,
    zeroCrossings: number[]
  ): Promise<LoopCandidate> {
    const startSample = Math.floor(startTime * sampleRate);
    const endSample = Math.floor(endTime * sampleRate);
    const duration = endTime - startTime;
    
    // Check for zero crossings near start and end
    const zeroCrossingStart = this.hasZeroCrossingNear(zeroCrossings, startTime, 0.05);
    const zeroCrossingEnd = this.hasZeroCrossingNear(zeroCrossings, endTime, 0.05);
    
    // Calculate rhythm score based on amplitude patterns
    const rhythmScore = this.calculateRhythmScore(channelData, startSample, endSample);
    
    // Calculate loop quality score
    const loopScore = this.calculateLoopScore(channelData, startSample, endSample);
    
    // Calculate overall confidence
    let confidence = 0;
    confidence += zeroCrossingStart ? 0.3 : 0;
    confidence += zeroCrossingEnd ? 0.3 : 0;
    confidence += rhythmScore * 0.2;
    confidence += loopScore * 0.2;
    
    return {
      startTime,
      endTime,
      duration,
      confidence,
      zeroCrossingStart,
      zeroCrossingEnd,
      rhythmScore
    };
  }

  private hasZeroCrossingNear(zeroCrossings: number[], targetTime: number, tolerance: number): boolean {
    return zeroCrossings.some(crossing => Math.abs(crossing - targetTime) <= tolerance);
  }

  private calculateRhythmScore(channelData: Float32Array, startSample: number, endSample: number): number {
    const windowSize = 1024;
    const hopSize = 512;
    let totalEnergy = 0;
    let peakCount = 0;
    
    for (let i = startSample; i < endSample - windowSize; i += hopSize) {
      let energy = 0;
      for (let j = 0; j < windowSize; j++) {
        energy += Math.abs(channelData[i + j]);
      }
      
      totalEnergy += energy;
      if (energy > totalEnergy / ((i - startSample) / hopSize + 1) * 1.5) {
        peakCount++;
      }
    }
    
    const avgEnergy = totalEnergy / Math.floor((endSample - startSample) / hopSize);
    return Math.min(peakCount / 10, 1.0) * Math.min(avgEnergy * 1000, 1.0);
  }

  private calculateLoopScore(channelData: Float32Array, startSample: number, endSample: number): number {
    const segmentLength = endSample - startSample;
    const compareLength = Math.min(segmentLength * 0.1, 2048); // Compare first and last 10% or 2048 samples
    
    let similarity = 0;
    for (let i = 0; i < compareLength; i++) {
      const startValue = channelData[startSample + i];
      const endValue = channelData[endSample - compareLength + i];
      similarity += 1 - Math.abs(startValue - endValue);
    }
    
    return similarity / compareLength;
  }

  async createAudioSlice(audioBuffer: AudioBuffer, startTime: number, endTime: number, crossfadeDuration: number = 0): Promise<AudioBuffer> {
    const startSample = Math.floor(startTime * audioBuffer.sampleRate);
    const endSample = Math.floor(endTime * audioBuffer.sampleRate);
    const length = endSample - startSample;
    
    const sliceBuffer = this.audioContext.createBuffer(
      audioBuffer.numberOfChannels,
      length,
      audioBuffer.sampleRate
    );
    
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const originalData = audioBuffer.getChannelData(channel);
      const sliceData = sliceBuffer.getChannelData(channel);
      
      for (let i = 0; i < length; i++) {
        sliceData[i] = originalData[startSample + i];
      }
    }
    
    // Apply crossfade if specified
    if (crossfadeDuration > 0) {
      return this.applyCrossfade(sliceBuffer, crossfadeDuration);
    }
    
    return sliceBuffer;
  }

  applyCrossfade(audioBuffer: AudioBuffer, crossfadeDuration: number): AudioBuffer {
    const crossfadeSamples = Math.floor(crossfadeDuration * audioBuffer.sampleRate);
    
    // Don't crossfade if duration is too short
    if (crossfadeSamples * 2 >= audioBuffer.length) {
      return audioBuffer;
    }
    
    // Create new buffer with crossfade applied
    const newBuffer = this.audioContext.createBuffer(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );
    
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const originalData = audioBuffer.getChannelData(channel);
      const newData = newBuffer.getChannelData(channel);
      
      // Copy original data
      for (let i = 0; i < audioBuffer.length; i++) {
        newData[i] = originalData[i];
      }
      
      // Apply fade-in at the beginning
      for (let i = 0; i < crossfadeSamples; i++) {
        const fadeInGain = i / crossfadeSamples; // 0 to 1
        const endSampleIndex = audioBuffer.length - crossfadeSamples + i;
        
        // Fade in from the end of the loop
        if (endSampleIndex < audioBuffer.length) {
          newData[i] = newData[i] * fadeInGain + originalData[endSampleIndex] * (1 - fadeInGain);
        }
      }
      
      // Apply fade-out at the end
      for (let i = 0; i < crossfadeSamples; i++) {
        const sampleIndex = audioBuffer.length - crossfadeSamples + i;
        const fadeOutGain = 1 - (i / crossfadeSamples); // 1 to 0
        const startSampleIndex = i;
        
        // Fade out to the beginning of the loop
        newData[sampleIndex] = newData[sampleIndex] * fadeOutGain + originalData[startSampleIndex] * (1 - fadeOutGain);
      }
    }
    
    return newBuffer;
  }

  createSeamlessLoop(audioBuffer: AudioBuffer, loopCount: number = 3, crossfadeDuration: number = 0.1): AudioBuffer {
    const originalLength = audioBuffer.length;
    const totalLength = originalLength * loopCount;
    const crossfadeSamples = Math.floor(crossfadeDuration * audioBuffer.sampleRate);
    
    const loopBuffer = this.audioContext.createBuffer(
      audioBuffer.numberOfChannels,
      totalLength,
      audioBuffer.sampleRate
    );
    
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const originalData = audioBuffer.getChannelData(channel);
      const loopData = loopBuffer.getChannelData(channel);
      
      for (let loop = 0; loop < loopCount; loop++) {
        const loopStart = loop * originalLength;
        
        // Copy the loop
        for (let i = 0; i < originalLength; i++) {
          loopData[loopStart + i] = originalData[i];
        }
        
        // Apply crossfade between loops (except for the last loop)
        if (loop < loopCount - 1 && crossfadeSamples > 0) {
          const fadeStart = loopStart + originalLength - crossfadeSamples;
          const fadeEnd = loopStart + originalLength;
          const nextLoopStart = (loop + 1) * originalLength;
          
          for (let i = 0; i < crossfadeSamples; i++) {
            const fadeIndex = fadeStart + i;
            const nextIndex = nextLoopStart + i;
            const fadeOutGain = 1 - (i / crossfadeSamples);
            const fadeInGain = i / crossfadeSamples;
            
            if (fadeIndex < totalLength && nextIndex < totalLength) {
              loopData[fadeIndex] = loopData[fadeIndex] * fadeOutGain + originalData[i] * fadeInGain;
            }
          }
        }
      }
    }
    
    return loopBuffer;
  }

  async exportAudioBuffer(audioBuffer: AudioBuffer, format: 'wav' | 'mp3' = 'wav'): Promise<Blob> {
    if (format === 'wav') {
      return this.audioBufferToWav(audioBuffer);
    }
    throw new Error('MP3 export not implemented yet');
  }

  private audioBufferToWav(audioBuffer: AudioBuffer): Blob {
    const length = audioBuffer.length * audioBuffer.numberOfChannels * 2;
    const buffer = new ArrayBuffer(44 + length);
    const view = new DataView(buffer);
    
    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, audioBuffer.numberOfChannels, true);
    view.setUint32(24, audioBuffer.sampleRate, true);
    view.setUint32(28, audioBuffer.sampleRate * audioBuffer.numberOfChannels * 2, true);
    view.setUint16(32, audioBuffer.numberOfChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length, true);
    
    // Audio data
    let offset = 44;
    for (let i = 0; i < audioBuffer.length; i++) {
      for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, audioBuffer.getChannelData(channel)[i]));
        view.setInt16(offset, sample * 0x7FFF, true);
        offset += 2;
      }
    }
    
    return new Blob([buffer], { type: 'audio/wav' });
  }
}