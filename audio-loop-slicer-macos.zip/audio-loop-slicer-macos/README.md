# 🎵 Audio Loop Slicer

A professional web application that analyzes uploaded audio files and extracts perfect looping slices with zero-crossing detection algorithms.

## ✨ Features

- **Smart Audio Analysis**: Advanced algorithms detect zero-crossing points and rhythm patterns
- **Automatic Slice Extraction**: AI identifies up to 3 optimal loop candidates (≤3 seconds each)
- **Interactive Waveform**: Visual display with click-to-seek and real-time audio playback
- **Manual Fine-tuning**: Complete user control over slice boundaries with real-time updates
- **Advanced Crossfade**: Adjustable crossfade transitions (50ms-500ms) for seamless looping
- **Seamless Loop Testing**: Dedicated loop mode with crossfade preview functionality
- **Professional Export**: Individual and batch WAV downloads with crossfade metadata
- **Multi-format Support**: MP3, WAV, M4A, AAC, OGG, FLAC compatibility
- **Demo Mode**: Includes sample audio files for immediate testing

## 🚀 Live Demo

Visit the live application: [Audio Loop Slicer](https://your-username.github.io/audio-loop-slicer)

## 🛠️ Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: TailwindCSS + shadcn/ui components
- **Audio Processing**: Web Audio API + Custom algorithms
- **Waveform Visualization**: WaveSurfer.js
- **Build Tool**: Vite with optimized production builds

## 🎯 Use Cases

Perfect for:
- Music producers seeking loop extraction
- Content creators needing audio samples
- Audio enthusiasts exploring loop creation
- Musicians working with sample-based production

## 🏃‍♂️ Quick Start

### Prerequisites
- Node.js 18+ and npm

### Installation
```bash
# Clone the repository
git clone https://github.com/your-username/audio-loop-slicer.git
cd audio-loop-slicer

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Deploy to GitHub Pages
This project includes automatic GitHub Pages deployment via GitHub Actions. Simply push to the main branch and your site will be automatically built and deployed.

## 🎵 How It Works

1. **Upload Audio**: Drag and drop audio files or use the file picker
2. **Automatic Analysis**: The app analyzes the audio for optimal loop points using zero-crossing detection
3. **Review Slices**: Preview up to 3 automatically generated loop candidates
4. **Manual Adjustment**: Fine-tune slice boundaries if needed
5. **Enable Crossfade**: Toggle crossfade transitions (50ms-500ms) for ultra-smooth looping
6. **Test Loops**: Use the loop mode to verify seamless playback with crossfade preview
7. **Export**: Download individual slices or all slices in a ZIP file with crossfade applied

## 🔧 Audio Processing Features

- **Zero-Crossing Detection**: Ensures clean cuts without audio artifacts
- **Rhythm Analysis**: Identifies musical patterns for optimal loop placement
- **Advanced Crossfade Engine**: Smooth transitions between loop start/end points
- **Quality Scoring**: Rates loop candidates based on seamlessness and musical coherence
- **Interactive Waveform Playback**: Real-time audio preview with visual feedback
- **Format Support**: Handles multiple audio formats with automatic conversion
- **Privacy-First**: All processing happens locally in your browser

## 📁 Project Structure

```
audio-loop-slicer/
├── src/
│   ├── components/          # React components
│   ├── lib/                # Audio processing utilities
│   ├── hooks/              # Custom React hooks
│   └── App.tsx             # Main application
├── public/                 # Static assets and demo files
├── dist/                   # Production build
└── .github/workflows/      # GitHub Actions deployment
```

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs or suggest features
- Submit pull requests
- Improve documentation
- Share usage examples

## 📄 License

This project is open source and available under the MIT License.

---

**Created by MiniMax Agent** - Advanced AI-powered audio processing for seamless loop creation.
